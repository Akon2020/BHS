"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { hasAccessToPage } from "@/lib/permissions";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Users,
  FileText,
  Mail,
  Calendar,
  Home,
  Settings,
  ChevronLeft,
  ChevronRight,
  UserCircle,
  Folder,
  LogOut,
  MessageSquare,
  IdCard,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { logout } from "@/actions/auth";

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

export default function AdminSidebar({ isOpen, onToggle }: SidebarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const { user } = useAuth();

  const handleLogout = async () => {
    try {
      await logout();

      router.push("/connexion");
      router.refresh();
    } catch (error) {
      console.error("Erreur de déconnexion :", error);
      toast?.error("Impossible de se déconnecter");
    }
  };

  const allRoutes = [
    {
      label: "Tableau de bord",
      icon: LayoutDashboard,
      href: "/admin",
      active: pathname === "/admin",
    },
    {
      label: "Utilisateurs",
      icon: Users,
      href: "/admin/users",
      active: pathname === "/admin/users",
    },
    {
      label: "Identités",
      icon: IdCard ,
      href: "/admin/identities",
      active: pathname.startsWith("/admin/identities"),
    },
    {
      label: "Catégories",
      icon: Folder,
      href: "/admin/categories",
      active: pathname.startsWith("/admin/categories"),
    },
    {
      label: "Blog",
      icon: FileText,
      href: "/admin/blog",
      active: pathname.startsWith("/admin/blog"),
    },
    {
      label: "Messages",
      icon: MessageSquare,
      href: "/admin/contact",
      active: pathname.startsWith("/admin/contact"),
    },
    {
      label: "Newsletter",
      icon: Mail,
      href: "/admin/newsletter",
      active: pathname.startsWith("/admin/newsletter"),
    },
    {
      label: "Événements",
      icon: Calendar,
      href: "/admin/events",
      active: pathname.startsWith("/admin/events"),
    },
    {
      label: "Équipe",
      icon: Users,
      href: "/admin/team",
      active: pathname.startsWith("/admin/team"),
    },
    {
      label: "Profil",
      icon: UserCircle,
      href: "/admin/profile",
      active: pathname === "/admin/profile",
    },
    {
      label: "Paramètres",
      icon: Settings,
      href: "/admin/settings",
      active: pathname === "/admin/settings",
    },
  ];

  // Filtrer les routes selon le rôle de l'utilisateur
  const routes = allRoutes.filter((route) => {
    if (!user) return false;
    return hasAccessToPage(user.role, route.href);
  });

  return (
    <div
      className={cn(
        "group/sidebar h-screen bg-background border-r relative transition-all duration-300 ease-in-out",
        isOpen ? "w-64" : "w-[70px]",
      )}
    >
      <div className="flex h-full flex-col">
        <div className="flex h-14 items-center border-b px-3 justify-between">
          <Link
            href="/admin"
            className={cn(
              "flex items-center gap-2 font-semibold transition-opacity",
              isOpen ? "opacity-100" : "opacity-0",
            )}
          >
            <span className="text-primary font-bold">Burning Heart</span>
          </Link>
          <Button
            onClick={onToggle}
            variant="ghost"
            size="icon"
            className="h-8 w-8"
          >
            {isOpen ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}
          </Button>
        </div>
        <ScrollArea className="flex-1 py-2">
          <nav className="grid gap-1 px-2">
            {routes.map((route) => (
              <Link
                key={route.href}
                href={route.href}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-all hover:bg-accent",
                  route.active
                    ? "bg-accent text-accent-foreground"
                    : "text-muted-foreground",
                )}
              >
                <route.icon size={20} />
                <span
                  className={cn(
                    "transition-opacity",
                    isOpen ? "opacity-100" : "opacity-0",
                  )}
                >
                  {route.label}
                </span>
              </Link>
            ))}
          </nav>
        </ScrollArea>
        <div className="mt-auto border-t p-2">
          <Button
            variant="ghost"
            asChild
            className={cn(
              "mb-1 w-full justify-start gap-3",
              isOpen ? "" : "justify-center",
            )}
          >
            <Link href="/">
              <Home size={20} />
              <span
                className={cn(
                  "transition-opacity",
                  isOpen ? "opacity-100" : "opacity-0",
                )}
              >
                Retour à l'accueil
              </span>
            </Link>
          </Button>

          <Button
            variant="ghost"
            onClick={handleLogout}
            className={cn(
              "w-full justify-start gap-3 text-destructive hover:text-destructive border-t",
              isOpen ? "" : "justify-center",
            )}
          >
            <LogOut size={20} />
            <span
              className={cn(
                "transition-opacity",
                isOpen ? "opacity-100" : "opacity-0",
              )}
            >
              Déconnexion
            </span>
          </Button>
        </div>
      </div>
    </div>
  );
}
