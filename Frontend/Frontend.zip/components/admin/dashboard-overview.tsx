"use client";

import Link from "next/link";
import {
  CalendarClock,
  Cake,
  ListTodo,
  ChevronRight,
  type LucideIcon,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { cn } from "@/lib/utils";
import type { DashboardResponse } from "@/types/dashboard";

const MOIS_COURTS = [
  "janv.",
  "févr.",
  "mars",
  "avr.",
  "mai",
  "juin",
  "juil.",
  "août",
  "sept.",
  "oct.",
  "nov.",
  "déc.",
];

const formatDate = (iso?: string | null) => {
  if (!iso) return "—";
  const [y, m, d] = iso.split("-").map(Number);
  return `${String(d).padStart(2, "0")} ${MOIS_COURTS[m - 1]} ${y}`;
};

const rdvBadge = (statut: string) =>
  statut === "approuve"
    ? "bg-primary/10 text-primary"
    : "bg-amber-500/10 text-amber-600 dark:text-amber-400";

const prioriteBadge = (p: string) =>
  p === "haute"
    ? "bg-destructive/10 text-destructive"
    : p === "basse"
      ? "bg-muted text-muted-foreground"
      : "bg-primary/10 text-primary";

/** Panneau générique avec titre, lien « voir tout » et contenu / état vide. */
function Panel({
  title,
  icon: Icon,
  href,
  isEmpty,
  emptyLabel,
  children,
}: {
  title: string;
  icon: LucideIcon;
  href: string;
  isEmpty: boolean;
  emptyLabel: string;
  children: React.ReactNode;
}) {
  return (
    <Card className="flex flex-col transition-shadow hover:shadow-md">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 p-4 pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <Icon className="h-4 w-4 text-primary" />
          {title}
        </CardTitle>
        <Link
          href={href}
          className="flex items-center text-xs text-muted-foreground transition-colors hover:text-primary"
        >
          Voir tout
          <ChevronRight className="h-3.5 w-3.5" />
        </Link>
      </CardHeader>
      <CardContent className="flex-1 p-4 pt-0">
        {isEmpty ? (
          <p className="py-4 text-center text-sm text-muted-foreground">
            {emptyLabel}
          </p>
        ) : (
          children
        )}
      </CardContent>
    </Card>
  );
}

/** Panneaux opérationnels : prochains RDV, anniversaires à venir, tâches à échéance. */
export default function DashboardOverview({
  data,
}: {
  data: DashboardResponse | null;
}) {
  if (!data) return null;

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
      <Panel
        title="Prochains rendez-vous"
        icon={CalendarClock}
        href="/admin/agenda"
        isEmpty={(data.rendezVous?.data?.length ?? 0) === 0}
        emptyLabel="Aucun rendez-vous à venir."
      >
        <ul className="space-y-2">
          {data.rendezVous.data.slice(0, 4).map((r) => (
            <li
              key={r.idRendezVous}
              className="flex items-center justify-between gap-2"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-medium leading-tight">
                  {r.nom}
                </p>
                <p className="text-xs text-muted-foreground">
                  {formatDate(r.date)} · {r.heureDebut?.slice(0, 5)}
                </p>
              </div>
              <span
                className={cn(
                  "shrink-0 rounded-full px-2 py-0.5 text-[10px] font-medium",
                  rdvBadge(r.statut),
                )}
              >
                {r.statut === "approuve" ? "Approuvé" : "En attente"}
              </span>
            </li>
          ))}
        </ul>
      </Panel>

      <Panel
        title="Anniversaires à venir"
        icon={Cake}
        href="/admin/anniversaires"
        isEmpty={(data.anniversaires?.data?.length ?? 0) === 0}
        emptyLabel="Aucun anniversaire configuré."
      >
        <ul className="space-y-2">
          {data.anniversaires.data.slice(0, 4).map((a) => (
            <li
              key={a.idAnniversaire}
              className="flex items-center justify-between gap-2"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-medium leading-tight">
                  {a.nom}
                </p>
                <p className="text-xs text-muted-foreground">
                  {String(a.jour).padStart(2, "0")} {MOIS_COURTS[a.mois - 1]}
                </p>
              </div>
              <span className="shrink-0 rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary">
                {a.dansJours === 0
                  ? "Aujourd'hui"
                  : a.dansJours === 1
                    ? "Demain"
                    : `J-${a.dansJours}`}
              </span>
            </li>
          ))}
        </ul>
      </Panel>

      <Panel
        title="Tâches à échéance"
        icon={ListTodo}
        href="/admin/taches"
        isEmpty={(data.taches?.data?.length ?? 0) === 0}
        emptyLabel="Aucune tâche planifiée."
      >
        <ul className="space-y-2">
          {data.taches.data.slice(0, 4).map((t) => (
            <li
              key={t.idTache}
              className="flex items-center justify-between gap-2"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-medium leading-tight">
                  {t.titre}
                </p>
                <p className="text-xs text-muted-foreground">
                  {formatDate(t.echeance)}
                </p>
              </div>
              <span
                className={cn(
                  "shrink-0 rounded-full px-2 py-0.5 text-[10px] font-medium",
                  prioriteBadge(t.priorite),
                )}
              >
                {t.priorite === "haute"
                  ? "Haute"
                  : t.priorite === "basse"
                    ? "Basse"
                    : "Normale"}
              </span>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
