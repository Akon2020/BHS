import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import type { User } from "@/types/user";

interface Props {
  users?: User[] | undefined;
}

const fallbackUsers = [
  {
    id: 1,
    name: "Samuel Diambu",
    email: "samueldiambu@gmail.com",
    avatar: "/placeholder.svg?height=40&width=40",
    status: "active",
    date: "Il y a 2 heures",
  },
  {
    id: 2,
    name: "Isaac Akonkwa",
    email: "akonkwaushindi@gmail.com",
    avatar: "/placeholder.svg?height=40&width=40",
    status: "active",
    date: "Il y a 5 heures",
  },
  {
    id: 3,
    name: "Wani Rudendeza",
    email: "wanirudendeza@gmail.com",
    avatar: "/placeholder.svg?height=40&width=40",
    status: "pending",
    date: "Il y a 1 jour",
  },
  {
    id: 4,
    name: "Père Ciza",
    email: "pere.ciza@gmail.com",
    avatar: "/placeholder.svg?height=40&width=40",
    status: "active",
    date: "Il y a 2 jours",
  },
  {
    id: 5,
    name: "David Cubaka",
    email: "davidcubaka.com",
    avatar: "/placeholder.svg?height=40&width=40",
    status: "inactive",
    date: "Il y a 3 jours",
  },
];

export default function AdminRecentUsers({ users }: Props) {
  const list =
    users && users.length > 0
      ? users.map((u) => ({
          id: u.idUtilisateur,
          name: u.nomComplet,
          email: u.email,
          avatar: `${process.env.NEXT_PUBLIC_API_URL}/${u.avatar}` || "/placeholder.svg",
          status: "active",
          date: new Date(u.createdAt).toLocaleDateString("fr-FR"),
        }))
      : fallbackUsers;

  return (
    <div className="space-y-4">
      {list.map((user) => (
        <div key={user.id} className="flex items-center gap-3">
          <div className="flex min-w-0 flex-1 items-center gap-3">
            <Avatar className="shrink-0">
              <AvatarImage
                src={user.avatar || "/placeholder.svg"}
                alt={user.name}
              />
              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <p className="truncate font-medium">{user.name}</p>
              <p className="truncate text-sm text-muted-foreground">
                {user.email}
              </p>
            </div>
          </div>
          <div className="flex shrink-0 flex-col items-end gap-1">
            <Badge
              variant={
                user.status === "active"
                  ? "default"
                  : user.status === "pending"
                    ? "outline"
                    : "secondary"
              }
            >
              {user.status === "active"
                ? "Actif"
                : user.status === "pending"
                  ? "En attente"
                  : "Inactif"}
            </Badge>
            <span className="whitespace-nowrap text-xs text-muted-foreground">
              {user.date}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}
