globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/ccd44a2583bb8cb2.js",
    "static/chunks/112f346e31f991df.js",
    "static/chunks/c462f7822a1dbf4e.js",
    "static/chunks/b580f392e1d07849.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/turbopack-19e2fe4fca20d87b.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];