module.exports=[50195,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_newsletter_page_actions_578887f4.js.map