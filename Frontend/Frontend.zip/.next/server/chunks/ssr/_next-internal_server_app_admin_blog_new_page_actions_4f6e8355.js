module.exports=[59750,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_blog_new_page_actions_4f6e8355.js.map