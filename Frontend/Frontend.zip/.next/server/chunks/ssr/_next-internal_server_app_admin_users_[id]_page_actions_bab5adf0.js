module.exports=[96915,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_users_%5Bid%5D_page_actions_bab5adf0.js.map