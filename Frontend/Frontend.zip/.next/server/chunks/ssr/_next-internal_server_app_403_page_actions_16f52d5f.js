module.exports=[12103,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_403_page_actions_16f52d5f.js.map