module.exports=[72220,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_don_page_actions_03f11611.js.map