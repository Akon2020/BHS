module.exports=[22302,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_team_new_page_actions_c964695a.js.map