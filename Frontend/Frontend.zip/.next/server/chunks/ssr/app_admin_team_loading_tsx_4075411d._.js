module.exports=[93763,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=app_admin_team_loading_tsx_4075411d._.js.map