module.exports=[74713,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_events_new_page_actions_7a376826.js.map