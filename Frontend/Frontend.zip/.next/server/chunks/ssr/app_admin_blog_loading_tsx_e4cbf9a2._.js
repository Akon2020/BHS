module.exports=[12642,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=app_admin_blog_loading_tsx_e4cbf9a2._.js.map