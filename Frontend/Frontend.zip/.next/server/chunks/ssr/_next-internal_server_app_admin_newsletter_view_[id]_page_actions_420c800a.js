module.exports=[25935,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_newsletter_view_%5Bid%5D_page_actions_420c800a.js.map