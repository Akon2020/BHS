module.exports=[67490,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_events_view_%5Bid%5D_page_actions_63509bab.js.map