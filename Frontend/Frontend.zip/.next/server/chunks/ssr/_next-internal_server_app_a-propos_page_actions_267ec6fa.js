module.exports=[56158,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_a-propos_page_actions_267ec6fa.js.map