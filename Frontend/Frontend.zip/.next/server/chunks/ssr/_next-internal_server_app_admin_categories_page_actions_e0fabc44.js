module.exports=[4280,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_categories_page_actions_e0fabc44.js.map