module.exports=[75270,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_blog_page_actions_94703150.js.map