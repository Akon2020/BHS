module.exports=[70351,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_blog_view_%5Bid%5D_page_actions_3ae5c8f3.js.map