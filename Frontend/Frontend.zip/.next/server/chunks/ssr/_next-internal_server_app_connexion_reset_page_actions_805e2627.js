module.exports=[12620,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_connexion_reset_page_actions_805e2627.js.map