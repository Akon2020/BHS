module.exports=[6748,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_newsletter_new_page_actions_84c7b26d.js.map