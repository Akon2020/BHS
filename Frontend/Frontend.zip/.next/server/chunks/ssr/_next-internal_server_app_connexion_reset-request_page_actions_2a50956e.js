module.exports=[65018,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_connexion_reset-request_page_actions_2a50956e.js.map