module.exports=[61914,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=app_admin_events_loading_tsx_9552f1ec._.js.map