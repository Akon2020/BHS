module.exports=[89078,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=app_admin_users_loading_tsx_afe536e0._.js.map