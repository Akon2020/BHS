module.exports=[11900,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_blog_%5Bslug%5D_page_actions_ec3909d7.js.map