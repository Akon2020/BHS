:HL["/_next/static/chunks/d3d5b0a71bbeff55.css","style"]
:HL["/_next/static/chunks/8c09a0e1fca49969.css","style"]
0:{"buildId":"jkL7KIJhKMJRTA-3DyABt","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
