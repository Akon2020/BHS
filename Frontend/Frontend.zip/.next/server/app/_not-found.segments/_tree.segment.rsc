:HL["/_next/static/chunks/d3d5b0a71bbeff55.css","style"]
:HL["/_next/static/chunks/61331ca7a41868da.css","style"]
0:{"buildId":"T-cs_KT769qB0jq3LsTpU","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
