1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/e63986417e1da667.js","/_next/static/chunks/247eb132b7f7b574.js","/_next/static/chunks/61c0b800563064f8.js"],"default"]
3:I[37457,["/_next/static/chunks/e63986417e1da667.js","/_next/static/chunks/247eb132b7f7b574.js","/_next/static/chunks/61c0b800563064f8.js"],"default"]
0:{"buildId":"jkL7KIJhKMJRTA-3DyABt","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
