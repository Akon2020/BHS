1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/4536e37dc64e351e.js","/_next/static/chunks/247eb132b7f7b574.js","/_next/static/chunks/61c0b800563064f8.js"],"default"]
3:I[37457,["/_next/static/chunks/4536e37dc64e351e.js","/_next/static/chunks/247eb132b7f7b574.js","/_next/static/chunks/61c0b800563064f8.js"],"default"]
0:{"buildId":"T-cs_KT769qB0jq3LsTpU","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
