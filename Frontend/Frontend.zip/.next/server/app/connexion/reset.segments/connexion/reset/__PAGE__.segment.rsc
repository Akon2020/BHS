1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[70913,["/_next/static/chunks/2c4b3c9382925f10.js","/_next/static/chunks/61c0b800563064f8.js","/_next/static/chunks/3d86f9aaf0992649.js","/_next/static/chunks/eb12a2fa8160daec.js"],"ResetFormSkeleton"]
4:I[70913,["/_next/static/chunks/2c4b3c9382925f10.js","/_next/static/chunks/61c0b800563064f8.js","/_next/static/chunks/3d86f9aaf0992649.js","/_next/static/chunks/eb12a2fa8160daec.js"],"ResetForm"]
5:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"OutletBoundary"]
0:{"buildId":"jkL7KIJhKMJRTA-3DyABt","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"flex h-screen items-center justify-center py-12","children":["$","div",null,{"className":"mx-auto w-full max-w-md px-4","children":["$","$2",null,{"fallback":["$","$L3",null,{}],"children":["$","$L4",null,{}]}]}]}],[["$","script","script-0",{"src":"/_next/static/chunks/3d86f9aaf0992649.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/eb12a2fa8160daec.js","async":true}]],["$","$L5",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"loading":null,"isPartial":false}
6:null
