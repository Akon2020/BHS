1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[70913,["/_next/static/chunks/25c084ee43962fba.js","/_next/static/chunks/61c0b800563064f8.js","/_next/static/chunks/d8d89f51be42998f.js","/_next/static/chunks/eb12a2fa8160daec.js"],"ResetFormSkeleton"]
4:I[70913,["/_next/static/chunks/25c084ee43962fba.js","/_next/static/chunks/61c0b800563064f8.js","/_next/static/chunks/d8d89f51be42998f.js","/_next/static/chunks/eb12a2fa8160daec.js"],"ResetForm"]
5:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"OutletBoundary"]
0:{"buildId":"T-cs_KT769qB0jq3LsTpU","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"flex h-screen items-center justify-center py-12","children":["$","div",null,{"className":"mx-auto w-full max-w-md px-4","children":["$","$2",null,{"fallback":["$","$L3",null,{}],"children":["$","$L4",null,{}]}]}]}],[["$","script","script-0",{"src":"/_next/static/chunks/d8d89f51be42998f.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/eb12a2fa8160daec.js","async":true}]],["$","$L5",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"loading":null,"isPartial":false}
6:null
