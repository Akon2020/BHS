1:"$Sreact.fragment"
2:I[84540,["/_next/static/chunks/2c4b3c9382925f10.js","/_next/static/chunks/61c0b800563064f8.js"],"ThemeProvider"]
3:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"default"]
4:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"default"]
5:I[36768,["/_next/static/chunks/2c4b3c9382925f10.js","/_next/static/chunks/61c0b800563064f8.js","/_next/static/chunks/add1cc938ea49e50.js"],"default"]
6:I[34863,["/_next/static/chunks/2c4b3c9382925f10.js","/_next/static/chunks/61c0b800563064f8.js"],"Toaster"]
7:I[2355,["/_next/static/chunks/2c4b3c9382925f10.js","/_next/static/chunks/61c0b800563064f8.js"],"Analytics"]
:HL["/_next/static/chunks/d3d5b0a71bbeff55.css","style"]
:HL["/_next/static/chunks/8c09a0e1fca49969.css","style"]
0:{"buildId":"jkL7KIJhKMJRTA-3DyABt","rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/d3d5b0a71bbeff55.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/8c09a0e1fca49969.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/2c4b3c9382925f10.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/61c0b800563064f8.js","async":true}]],["$","html",null,{"lang":"fr","suppressHydrationWarning":true,"children":[["$","head",null,{"children":["$","link",null,{"rel":"icon","type":"image/png","href":"/images/logon.png"}]}],["$","body",null,{"className":"inter_b2991b2-module__9mH_6q__variable crimson_pro_2ed2e0e7-module__pKdJtG__variable font-sans antialiased","children":[["$","$L2",null,{"children":[["$","main",null,{"className":"min-h-screen","children":["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}],"notFound":[["$","$L5",null,{}],[]]}]}],["$","$L6",null,{}]]}],["$","$L7",null,{}]]}]]}]]}],"loading":null,"isPartial":false}
