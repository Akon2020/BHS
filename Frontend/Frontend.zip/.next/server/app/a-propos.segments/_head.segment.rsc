1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"ViewportBoundary"]
4:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"MetadataBoundary"]
5:"$Sreact.suspense"
7:I[27201,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"IconMark"]
0:{"buildId":"jkL7KIJhKMJRTA-3DyABt","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":"$@3"}],["$","div",null,{"hidden":true,"children":["$","$L4",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":"$@6"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
3:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","media":"(prefers-color-scheme: light)","content":"#8B1538"}],["$","meta","3",{"name":"theme-color","media":"(prefers-color-scheme: dark)","content":"#0a0a0a"}]]
6:[["$","title","0",{"children":"À propos - Burning Heart"}],["$","meta","1",{"name":"description","content":"Découvrez notre histoire, notre mission et nos valeurs"}],["$","link","2",{"rel":"icon","href":"/images/logon.png","media":"(prefers-color-scheme: light)"}],["$","link","3",{"rel":"icon","href":"/images/logon.png","media":"(prefers-color-scheme: dark)"}],["$","link","4",{"rel":"icon","href":"/images/logon.png","type":"image/png"}],["$","link","5",{"rel":"apple-touch-icon","href":"/images/logon.png"}],["$","$L7","6",{}]]
