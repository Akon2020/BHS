module.exports=[18209,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_identities_page_actions_c3cab0e3.js.map