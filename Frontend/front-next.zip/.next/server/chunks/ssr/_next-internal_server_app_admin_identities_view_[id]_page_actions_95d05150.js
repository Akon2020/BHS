module.exports=[61813,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_identities_view_%5Bid%5D_page_actions_95d05150.js.map