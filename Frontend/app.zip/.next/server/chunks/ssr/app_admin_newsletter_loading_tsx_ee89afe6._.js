module.exports=[59016,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=app_admin_newsletter_loading_tsx_ee89afe6._.js.map